<?php
// @deprecated 3.6.0 Backwards compatibility alias
class_alias('Cake\Http\Session', 'Cake\Network\Session');
deprecationWarning('Use Cake\Http\Session instead of Cake\Network\Session.');
