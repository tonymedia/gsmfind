<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\NotAcceptableException', 'Cake\Network\Exception\NotAcceptableException');
deprecationWarning('Use Cake\Http\Exception\NotAcceptableException instead of Cake\Network\Exception\NotAcceptableException.');
