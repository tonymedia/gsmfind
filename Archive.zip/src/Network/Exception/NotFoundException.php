<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\NotFoundException', 'Cake\Network\Exception\NotFoundException');
deprecationWarning('Use Cake\Http\Exception\NotFoundException instead of Cake\Network\Exception\NotFoundException.');
