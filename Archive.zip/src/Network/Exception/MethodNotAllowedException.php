<?php
// @deprecated 3.6.0 Backward compatibility alias
class_alias('Cake\Http\Exception\MethodNotAllowedException', 'Cake\Network\Exception\MethodNotAllowedException');
deprecationWarning('Use Cake\Http\Exception\MethodNotAllowedException instead of Cake\Network\Exception\MethodNotAllowedException.');
